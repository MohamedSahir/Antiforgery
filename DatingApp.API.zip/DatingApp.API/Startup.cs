﻿using System.Net;
using System.Text;
using AutoMapper;
using DatingApp.API.Data;
using DatingApp.API.filter;
using DatingApp.API.Helpers;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;

namespace DatingApp.API
{
    public class Startup
    {
        public Startup (IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices (IServiceCollection services)
        {
            // services.AddDbContext<DataContext>(x => x.UseSqlite(Configuration.GetConnectionString("DefaultConnection"))); // edit this to change the db provider
            services.AddDbContext<DataContext> (x =>
                x.UseSqlServer (Configuration.GetConnectionString ("DefaultConnection")));
            // .ConfigureWarnings (warnings => warnings.Ignore (CoreEventId.IncludeIgnoredWarning)));




            //services.AddCors(options =>
            //{
            //    options.AddPolicy("AllowAllOrigins",
            //        builder =>
            //        {
            //            builder.SetIsOriginAllowedToAllowWildcardSubdomains()
            //                .WithOrigins("https://conference-xplatform-client.azurewebsites.net", "http://localhost:5000", "http://localhost:4200", "https://localhost:4200", "http://localhost:404",
            //                "http://localhost:408", "http://localhost:409", "http://127.0.0.1:8887")
            //                .AllowAnyHeader()
            //                .AllowAnyMethod()
            //                .AllowCredentials();
            //        });
            //});




            services.AddControllers ()
                .AddNewtonsoftJson (opt =>
                {
                    opt.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                });

            // services.AddMvc ().SetCompatibilityVersion (CompatibilityVersion.Version_2_2)
            //     .AddJsonOptions (opts =>
            //     {
            //         opts.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            //     });

            //services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");

            //services.AddCors ();
            services.AddMvcCore()
             .AddViews();
            services.Configure<CloudinarySettings> (Configuration.GetSection ("CloudinarySettings"));
            services.AddAutoMapper (typeof (DatingRepository).Assembly);
            services.AddTransient<Seed> ();
            // created once per request withing the current scope
            services.AddScoped<IAuthRepository, AuthRepository> ();
            services.AddScoped<IDatingRepository, DatingRepository> ();
            services.AddAuthentication (JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer (options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey (Encoding.ASCII.GetBytes (Configuration.GetSection ("AppSettings:Token").Value)),
                    ValidateIssuer = false,
                    ValidateAudience = false
                    };
                });
            services.AddScoped<LogUserActivity> ();
            services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");
        }

        // This configuration used in development mode
        public void ConfigureDevelopmentServices (IServiceCollection services)
        {
            services.AddDbContext<DataContext> (x => x.UseSqlite (Configuration.GetConnectionString ("DefaultConnection"))); // edit this to change the db provider

            services.AddControllers ()
                .AddNewtonsoftJson (opt =>
                {
                    opt.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                });
            // services.AddMvc ().SetCompatibilityVersion (CompatibilityVersion.Version_2_1)
            //     .AddJsonOptions (opts =>
            //     {
            //         opts.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
            //     });

            // services.BuildServiceProvider().GetService<DataContext>().Database.Migrate(); // applies migrations to db
            // services.AddCors 
            services.AddMvcCore()
                .AddViews();

            //services.AddCors(options =>
            //{
            //    options.AddPolicy("AllowAllOrigins",
            //        builder =>
            //        {
            //            builder
            //                .WithOrigins("https://conference-xplatform-client.azurewebsites.net", "http://localhost:5000", "http://localhost:4200", "https://localhost:4200", "http://localhost:404",
            //                "http://localhost:408", "http://localhost:409", "http://127.0.0.1:8887")
            //                .AllowAnyHeader()
            //                .AllowAnyMethod()
            //                .AllowCredentials();
            //        });
            //});

           // services.AddAntiforgery(options => options.HeaderName = "X-XSRF-TOKEN");
            services.Configure<CloudinarySettings> (Configuration.GetSection ("CloudinarySettings"));
            services.AddAutoMapper (typeof (DatingRepository).Assembly);
            services.AddTransient<Seed> ();
            // created once per request withing the current scope
            services.AddScoped<IAuthRepository, AuthRepository> ();
            services.AddScoped<IDatingRepository, DatingRepository> ();
            services.AddAuthentication (JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer (options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey (Encoding.ASCII.GetBytes (Configuration.GetSection ("AppSettings:Token").Value)),
                    ValidateIssuer = false,
                    ValidateAudience = false
                    };
                });
            services.AddScoped<LogUserActivity> ();
            services.AddAntiforgery(options =>
            {
                options.HeaderName = "X-XSRF-TOKEN";
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure (IApplicationBuilder app, IWebHostEnvironment env, IAntiforgery antiforgery)
        {
            if (env.IsDevelopment ())
            {
                app.UseDeveloperExceptionPage ();
            }
            else
            {
                app.UseExceptionHandler (builder =>
                {
                    builder.Run (async context =>
                    {
                        context.Response.StatusCode = (int) HttpStatusCode.InternalServerError;
                        var error = context.Features.Get<IExceptionHandlerFeature> ();
                        if (error != null)
                        {
                            context.Response.AddApplicationError (error.Error.Message);
                            await context.Response.WriteAsync (error.Error.Message);
                        }
                    });
                });
                // app.UseHsts();
            }

            //// app.UseHttpsRedirection();
            //    app.UseAntiforgeryToken();

            //app.UseCors("AllowAllOrigins");
            app.UseRouting ();
            app.UseAuthentication ();
            app.UseAuthorization ();

            app.UseCors (x => x.AllowAnyOrigin ().AllowAnyMethod ().AllowAnyHeader ());
        

            //app.UseAntiforgeryToken();


            app.UseDefaultFiles (); // looks for a default file eg: index.html
            app.UseStaticFiles (); // to use the Angular SPA
            app.Use(async (context, next) =>
            {
                string path = context.Request.Path.Value;
                if (path != null && path.ToLower().Contains("/api"))
                {
                    //XSRF - TOKEN used by angular in the $http if provided

                    // var tokens = antiforgery.GetAndStoreTokens(context);
                    //context.Response.Cookies.Append("XSRF-TOKEN",
                    //  tokens.RequestToken, new CookieOptions
                    //  {
                    //      HttpOnly = false,
                    //      Secure = false
                    //  }
                    //); ;


                    AntiforgeryTokenSet tokens = antiforgery.GetAndStoreTokens(context);
                    context.Response.Cookies.Append("XSRF-TOKEN", tokens.RequestToken, new CookieOptions()
                    {
                        HttpOnly = false,
                        Secure = false,
                        IsEssential = true,
                        SameSite = SameSiteMode.Strict
                    });
                }


                await next();
            });


            //app.Use(nextDelegate => context =>
            //{
            //    string path = context.Request.Path.Value.ToLower();
            //    string[] directUrls = { "/admin", "/store", "/cart", "checkout", "/login" };
            //    if (path.StartsWith("/swagger") || path.StartsWith("/api") || string.Equals("/", path) || directUrls.Any(url => path.StartsWith(url)))
            //    {
            //        AntiforgeryTokenSet tokens = antiforgery.GetAndStoreTokens(context);
            //        context.Response.Cookies.Append("XSRF-TOKEN", tokens.RequestToken, new CookieOptions()
            //        {
            //            HttpOnly = false,
            //            Secure = false,
            //            IsEssential = true,
            //            SameSite = SameSiteMode.Strict
            //        });

            //    }

            //    return nextDelegate(context);
            //});
            app.UseEndpoints (endpoints =>
            {
                endpoints.MapControllers ();
                endpoints.MapFallbackToController ("Index", "Fallback");
            });
        }
    }
}